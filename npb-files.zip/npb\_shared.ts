export const NPB_TEAMS: Record<string, { code: string; ko: string; league: "Central" | "Pacific" }> = {
  "Hanshin Tigers": { code: "t", ko: "한신 타이거스", league: "Central" },
  "Yomiuri Giants": { code: "g", ko: "요미우리 자이언츠", league: "Central" },
  "YOKOHAMA DeNA BAYSTARS": { code: "db", ko: "요코하마 DeNA 베이스타스", league: "Central" },
  "Chunichi Dragons": { code: "d", ko: "주니치 드래건스", league: "Central" },
  "Hiroshima Toyo Carp": { code: "c", ko: "히로시마 도요 카프", league: "Central" },
  "Tokyo Yakult Swallows": { code: "s", ko: "도쿄 야쿠르트 스왈로스", league: "Central" },
  "Fukuoka SoftBank Hawks": { code: "h", ko: "후쿠오카 소프트뱅크 호크스", league: "Pacific" },
  "Hokkaido Nippon-Ham Fighters": { code: "f", ko: "홋카이도 닛폰햄 파이터스", league: "Pacific" },
  "ORIX Buffaloes": { code: "b", ko: "오릭스 버팔로스", league: "Pacific" },
  "Tohoku Rakuten Golden Eagles": { code: "e", ko: "도호쿠 라쿠텐 골든이글스", league: "Pacific" },
  "Saitama Seibu Lions": { code: "l", ko: "사이타마 세이부 라이온스", league: "Pacific" },
  "Chiba Lotte Marines": { code: "m", ko: "지바 롯데 마린스", league: "Pacific" },
};

export function findTeam(value: string) {
  const clean = value.trim().toLowerCase();
  return Object.entries(NPB_TEAMS).find(([english, data]) =>
    english.toLowerCase() === clean || data.ko.toLowerCase() === clean,
  )?.[1] ?? null;
}

export function cleanHtml(value: string) {
  return value
    .replace(/<script[\s\S]*?<\/script>/gi, "")
    .replace(/<style[\s\S]*?<\/style>/gi, "")
    .replace(/&nbsp;|&#160;/gi, " ")
    .replace(/&amp;/gi, "&")
    .replace(/&#39;/gi, "'")
    .replace(/&quot;/gi, '"')
    .replace(/<[^>]+>/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

export function tableRows(html: string) {
  return (html.match(/<tr\b[^>]*>[\s\S]*?<\/tr>/gi) ?? [])
    .map((row) => (row.match(/<t[dh]\b[^>]*>[\s\S]*?<\/t[dh]>/gi) ?? []).map(cleanHtml))
    .filter((cells) => cells.length > 1);
}

export function num(value: string | undefined) {
  const parsed = Number((value ?? "").replace(/,/g, "").replace(/[^0-9.-]/g, ""));
  return Number.isFinite(parsed) ? parsed : 0;
}

export function inningsToOuts(value: string | undefined) {
  const text = (value ?? "0").trim();
  const [whole, fraction = "0"] = text.split(".");
  const outs = Number(whole || 0) * 3 + (fraction === "1" ? 1 : fraction === "2" ? 2 : 0);
  return Number.isFinite(outs) ? outs : 0;
}

export function outsToInnings(outs: number) {
  return `${Math.floor(outs / 3)}.${outs % 3}`;
}
